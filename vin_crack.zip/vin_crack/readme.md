from the vin_crack directory
make clean (if needed)
make all
make test

Expected output is the plaintext of cat_story with the key as KEY

It uses statistical analysis of letter distribution found on Wikipedia 
Unfortunately it just brute forces the key
it works for uppercase letters