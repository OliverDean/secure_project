from the caesar_crack directory

make clean (if needed)
make all
make test

expected output is:
Best rotation: 13
Probability score: 634.99
First 50 words of decrypted output:
In a cozy little house on the edge of a bustling city lived a small, curious cat named Whiskers. Whiskers was a fluffy, orange tabby with bright green eyes and a tail that always seemed to be twitching with excitement. He loved his home and his kind owner, Mrs. Thompson,